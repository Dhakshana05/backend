import { Component, OnInit } from '@angular/core';
import { HotelService } from '../../services/hotel.service';
import { RoomService } from '../../services/room.service';
import { ReservationService } from '../../services/reservation.service';
import { PaymentService } from '../../services/payment.service';
import { ReviewService } from '../../services/review.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
// import { NgChartsModule } from 'ng2-charts';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule],  //NgChartsModule
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  statistics = [
    { title: 'Total Hotels', count: 0 },
    { title: 'Total Rooms', count: 0 },
    { title: 'Total Reservations', count: 0 },
    { title: 'Total Payments', count: 0 },
    { title: 'Total Reviews', count: 0 }
  ];

  revenueAmounts: number[] = []; // Store revenue amounts separately
  labels: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];

  chartOptions = {
    responsive: true
  };

  constructor(
    private hotelService: HotelService,
    private roomService: RoomService,
    private reservationService: ReservationService,
    private paymentService: PaymentService,
    private reviewService: ReviewService
  ) {}

  ngOnInit(): void {
    this.loadDashboardData();
  }

  loadDashboardData() {
    this.hotelService.getAllHotels().subscribe(data => this.statistics[0].count = data.length);
    this.roomService.getRooms().subscribe(data => this.statistics[1].count = data.length);
    this.reservationService.getAllReservations().subscribe(data => this.statistics[2].count = data.length);
    this.paymentService.getPayments().subscribe((data: { amount: number }[]) => {
      this.statistics[3].count = data.length;
      this.revenueAmounts = data.map(p => p.amount); // Store revenue separately
    });
    this.reviewService.getAllReviews().subscribe(data => this.statistics[4].count = data.length);
  }
}
