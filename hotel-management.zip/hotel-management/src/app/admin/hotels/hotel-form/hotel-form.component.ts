import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { HotelService } from 'src/app/services/hotel.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HotelService } from '../../../services/hotel.service';

@Component({
  selector: 'app-hotel-form',
  templateUrl: './hotel-form.component.html',
  styleUrls: ['./hotel-form.component.scss']
})
export class HotelFormComponent implements OnInit {
  hotelForm!: FormGroup;
  // isEdit = false;
  hotelId!: number;
  isEditMode: boolean = false;
  isEdit: boolean | undefined;

  constructor(
    private fb: FormBuilder,
    private hotelService: HotelService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.hotelForm = this.fb.group({
      name: ['', Validators.required],
      location: ['', Validators.required]
    });

    this.hotelId = Number(this.route.snapshot.paramMap.get('id'));
    if (this.hotelId) {
      this.isEditMode = true;
      this.hotelService.getHotelById(this.hotelId).subscribe(data => {
        this.hotelForm.patchValue(data);
      });
    }
  }

  submitForm(): void {
    if (this.isEditMode) {
      this.hotelService.updateHotel(this.hotelId, this.hotelForm.value).subscribe(() => {
        this.router.navigate(['/hotel']);
      });
    } else {
      this.hotelService.addHotel(this.hotelForm.value).subscribe(() => {
        this.router.navigate(['/hotel']);
      });
    }
  }
}
