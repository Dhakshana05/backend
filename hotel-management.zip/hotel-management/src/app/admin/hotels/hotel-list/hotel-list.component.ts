import { Component } from '@angular/core';

@Component({
  selector: 'app-hotel-list',
  standalone: true,
  imports: [],
  templateUrl: './hotel-list.component.html',
  styleUrl: './hotel-list.component.css',
})
export class HotelListComponent {}
