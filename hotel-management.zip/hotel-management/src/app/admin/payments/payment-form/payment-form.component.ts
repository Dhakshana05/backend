import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { PaymentService } from 'src/app/services/payment.service';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../../../services/payment.service';

@Component({
  selector: 'app-payment-form',
  templateUrl: './payment-form.component.html',
  styleUrls: ['./payment-form.component.scss']
})
export class PaymentFormComponent implements OnInit {
  paymentForm!: FormGroup;
  isEdit: boolean = false;
  paymentId!: number;

  constructor(
    private fb: FormBuilder,
    private paymentService: PaymentService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.paymentForm = this.fb.group({
      reservationId: ['', Validators.required],
      amount: ['', Validators.required],
      paymentDate: ['', Validators.required],
      paymentStatus: ['', Validators.required]
    });

    this.paymentId = Number(this.route.snapshot.paramMap.get('id'));
    if (this.paymentId) {
      this.isEdit = true;
      this.paymentService.getPaymentById(this.paymentId).subscribe(data => {
        this.paymentForm.patchValue(data);
      });
    }
  }


  submitForm(): void {
    if (this.isEdit) {
      this.paymentService.updatePayment(this.paymentId, this.paymentForm.value).subscribe(() => {
        this.router.navigate(['/payment']);
      });
    } else {
      this.paymentService.addPayment(this.paymentForm.value).subscribe(() => {
        this.router.navigate(['/payment']);
      });
    }
  }
}