import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../../../services/payment.service';
import { AuthService } from '../../../services/auth.service';
// import { PaymentService } from 'src/app/services/payment.service';

@Component({
  selector: 'app-payment-list',
  templateUrl: './payment-list.component.html',
  styleUrls: ['./payment-list.component.scss']
})
export class PaymentListComponent implements OnInit {
  payments: any[] = [];
  totalRevenue: number = 0;
  isAdmin: boolean = false;

  constructor(private paymentService: PaymentService, private authService: AuthService) {}

  ngOnInit(): void {
    this.fetchPayments();
    this.fetchTotalRevenue();
    this.isAdmin = this.authService.getUserRole() === 'ADMIN';
  }

  fetchPayments(): void {
    this.paymentService.getPayments().subscribe(data => {
      this.payments = data;
    });
  }

  fetchTotalRevenue(): void {
    this.paymentService.getTotalRevenue().subscribe(data => {
      this.totalRevenue = data;
    });
  }
  
  // loadPayments() {
  //   this.paymentService.getPayments().subscribe((data) => {
  //     this.payments = data;
  //   });
  // }

  deletePayment(paymentId: number): void {
    if (confirm('Are you sure you want to delete this payment?')) {
      this.paymentService.deletePayment(paymentId).subscribe(() => {
        this.payments = this.payments.filter(p => p.id !== paymentId);
      });
    }
  }
}
