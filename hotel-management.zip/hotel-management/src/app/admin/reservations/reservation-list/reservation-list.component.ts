import { Component, OnInit } from '@angular/core';
import { ReservationService } from '../../../services/reservation.service';
import { AuthService } from '../../../services/auth.service';
// import { ReservationService } from 'src/app/services/reservation.service';

@Component({
  selector: 'app-reservation-list',
  templateUrl: './reservation-list.component.html',
  styleUrls: ['./reservation-list.component.css']
})
export class ReservationListComponent implements OnInit {
  reservations: any[] = [];
  isAdmin: boolean = false;

  constructor(
    private reservationService: ReservationService, 
    private authService: AuthService) {}

  ngOnInit(): void {
    this.fetchReservations();
    this.isAdmin = this.authService.getUserRole() === 'ADMIN';
  }
  
  fetchReservations(): void {
    this.reservationService.getAllReservations().subscribe(data => {
      this.reservations = data;
    });
  }

  deleteReservation(reservationId: number): void {
    if (confirm('Are you sure you want to delete this reservation?')) {
      this.reservationService.deleteReservation(reservationId).subscribe(() => {
        this.reservations = this.reservations.filter(r => r.id !== reservationId);
      });
    }
  }
}
