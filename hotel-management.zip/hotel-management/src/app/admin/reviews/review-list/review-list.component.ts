import { Component, OnInit } from '@angular/core';
import { ReviewService } from '../../../services/review.service';
import { AuthService } from '../../../services/auth.service';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
// import { ReviewService } from 'src/app/services/review.service';

@Component({
  selector: 'app-review-list',
  standalone: true,
  imports: [CommonModule, RouterModule], // Only necessary modules
  templateUrl: './review-list.component.html',
  styleUrls: ['./review-list.component.css']
})
export class ReviewListComponent implements OnInit {
  reviews: any[] = [];
  isAdmin: boolean = false;

  constructor(private reviewService: ReviewService, private authService: AuthService) {}

  ngOnInit(): void {
    this.fetchReviews();
    this.isAdmin = this.authService.getUserRole() === 'ADMIN';
  }

  fetchReviews(): void {
    this.reviewService.getAllReviews().subscribe(data => {
      this.reviews = data;
    });
  }

  // loadReviews() {
  //   this.reviewService.getAllReviews().subscribe((data) => {
  //     this.reviews = data;
  //   });
  // }

  deleteReview(reviewId: number): void {
    if (confirm('Are you sure you want to delete this review?')) {
      this.reviewService.deleteReview(reviewId).subscribe(() => {
        this.reviews = this.reviews.filter(r => r.reviewId !== reviewId);
      });
    }
  }
}
