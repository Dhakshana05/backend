import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Chart } from 'chart.js/auto';

@Component({
  selector: 'app-dashboard-chart',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './dashboard-chart.component.html',
  styleUrls: ['./dashboard-chart.component.scss']
})
export class DashboardChartComponent implements OnInit {
  ngOnInit(): void {
    this.createChart();
  }

  createChart(): void {
    new Chart('paymentChart', {
      type: 'bar',
      data: {
        labels: ['Completed', 'Pending', 'Failed'],
        datasets: [{
          label: 'Payments',
          data: [80, 15, 5],
          backgroundColor: ['green', 'orange', 'red']
        }]
      }
    });
  }
}
