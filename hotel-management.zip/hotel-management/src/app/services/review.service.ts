import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {
  private apiUrl = 'http://localhost:8080/api/review';

  constructor(private http: HttpClient) {}

  getAllReviews(): Observable<any> {
    return this.http.get(`${this.apiUrl}/all`);
  }

  getReviewByRating(rating: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/rating/${rating}`);
  }

  getRecentReviews(): Observable<any> {
    return this.http.get(`${this.apiUrl}/recent`);
  }

  addReview(review: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/post`, review);
  }

  updateReview(reviewId: number, review: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/update/${reviewId}`, review);
  }

  deleteReview(reviewId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/delete/${reviewId}`);
  }
}